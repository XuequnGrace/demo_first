sap.ui.define([
    "mt/fin/ap/ab/controller/BaseController"
], function(Controller) {
    'use strict';
    return Controller.extend("mt.fin.ap.ab.controller.App", {
       
    })
   
});