sap.ui.define(["mt/fin/ap/ab/controller/BaseController"],function(e){"use strict";return e.extend("mt.fin.ap.ab.controller.App",{})});
//# sourceMappingURL=App.controller.js.map